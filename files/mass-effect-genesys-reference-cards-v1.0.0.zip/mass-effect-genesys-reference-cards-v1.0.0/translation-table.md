# Translation Table (English -> German)

This document lists the translations I did for rule terminology.

## General Rule Terminology

| English             | German                  |
|---------------------|-------------------------|
| Characteristic      | Eigenschaft             |
| Skill               | Fertigkeit              |
| Ability             | Fähigkeit               |
| Power               | Fähigkeit               |
| Upgrade             | Aufwerten               |
| Downgrade           | Abwerten                |
| Increase            | Erhöhen                 |
| Decrease            | Verringern              |
| Soak                | Polster                 |
| Wounds              | Wunden                  |
| Strain              | Stress                  |
| Threshold           | Schwelle                |
| Defense             | Abwehr                  |
| Rank                | Rang                    |
| Rating              | Wert                    |
| Encounter           | Begegnung               |
| Round               | Runde                   |
| Turn                | Zug                     |
| Incidental          | spontan                 |
| out-of-turn         | unplanmäßig             |
| Opponent            | Gegner                  |
| Adversary           | Widersacher             |


## Characteristics

| English             | German                  |
|---------------------|-------------------------|
| Brawn               | Muskeln                 |
| Agility             | Geschick                |
| Intellect           | Intellekt               |
| Cunning             | List                    |
| Willpower           | Wille                   |
| Presence            | Präsenz                 |

## Skills

| English             | German                  |
|---------------------|-------------------------|
| Biotics             | Biotik                  |
| Brawl               | Raufen                  |
| Charm               | Charme                  |
| Coercion            | Nötigen                 |
| Cool                | Cool                    |
| Coordination        | Koordination            |
| Discipline          | Disziplin               |
| Driving             | Fahren                  |
| Knowledge           | Wissen                  |
|     LifeSci         |     Leben               |
|     PhysSci         |     Physik              |
|     Society         |     Gesellschaft        |
|     Warfare         |     Kriegskunst         |
| Leadership          | Führung                 |
| Melee               | Nahkampf                |
| Negotiation         | Verhandeln              |
| Operating           | Kommandieren            |
| Piloting            | Steuern                 |
| Ranged              | Fern                    |
|     Light           |     Leicht              |
|     Heavy           |     Schwer              |
| Tech                | Tech                    |
| Vigilance           | Wachsamkeit             |
