# Referenzkarten für das Mass Effect Genesys Setting

Basiert auf dem [Mass Effect Setting][1] für [Genesys][2] von BluSunrize.

Erstellt von [flyx][3].

## Inhalt

 * `player-english.pdf`: Englische Kartenseiten für die Spielerkarten.
 * `player-german.pdf`: Deutsche Kartenseiten für die Spielerkarten.

Die deutschen und englischen Kartenseiten passen 1:1 aufeinander, das heißt, jede Information auf einer bestimmen Seite des englischen PDFs findet sich auf derselben Seite des deutschen PDFs.
Der Gedanke dahinter ist, die Karten beidseitig zu drucken.
Leider bedeutet das auch, dass die Listen auf den deutschen Karten nicht alphabetisch geordnet sind.

## Übersetzung

Die Übersetzung von Regelbegriffen findet sich beiliegend in `translation-table.md`.
Im deutschen Text werden weibliche Formen für Spielercharaktere und Alliierte benutzt und männliche Formen für Gegner.

## Format und Druck

Die PDFs sind erstellt entsprechend der Designvorgaben von [Mein Spiel][4]:

 * Das Zielformat der Karten ist 59*91mm.
 * Die PDFs beinhalten einen Beschnittrand von 3mm.
 * Der Textinhalt hat einen 4mm Abstand vom Kartenrand..
 * Das Farbformat ist CMYK mit dem Profil *ISO-coated v2 300% ECI*.
 * Die PDF-Version ist *PDF/X-4*.

Die Karten können über [diesen Link][5] bei Mein Spiel gedruckt werden, wo das Format 59*91mm und die Option für 55 Karten gewählt werden müssen.

Falls du die Karten woanders drucken willst, wo abweichende Vorgaben gemacht werden, kannst du mich kontaktieren.
Ich kann etwa relativ problemlos den Beschnittrand anpassen, weil das das Design nicht ändern.
Allerdings kann natürlich ich das Kartendesign nicht ohne erheblichen Aufwand für ein anderes Kartenformat anpassen.

## Kontakt

Für Fragen und Anregungen kannst du mich per Mail via `contact@flyx.org` erreichen, oder auf [Matrix][6] via `@flyx:klacker.eu`.

 [1]: https://www.reddit.com/r/genesysrpg/comments/1or4znp/mass_effect_setting_version_20/
 [2]: https://www.fantasyflightgames.com/en/products/genesys/
 [3]: https://flyx.org/
 [4]: https://www.meinspiel.de/gestaltungsleitfaden-spielkarten-format-59x91-mm/
 [5]: https://www.meinspiel.de/selbstgestaltete-spielkarten-mit-fotos-gestalten-drucken/
 [6]: https://matrix.org/
