# Reference cards for the Mass Effect Genesys setting

Based on the [Mass Effect Setting][1] for [Genesys][2] by BluSunrize.

Made by [flyx][3].

## Contained PDFs

 * `player-english.pdf`: English card faces of the card set for players.
 * `player-german.pdf`: German card faces of the card set for players.

The German and English card faces match 1:1, i.e. any information on a certain page in the English PDF will be on the same page in the German PDF.
This is so that you can print them back-to-back.
Sadly, this also means that the lists in the German PDFs are not sorted alphabetically.

## Translation

The translations of rule terms are listed in `translation-table.md`.
The German text uses female inflections for referencing player characters and allies, and male inflections for opponents.

## Format and Printing

These PDFs have been designed to the specifications of [Mein Spiel][4]:

 * The card format shall be 59*91mm.
 * The PDFs include a cutout border of 3mm.
 * The text content has a 4mm minimum padding to the card border.
 * CMYK colors with profile *ISO-coated v2 300% ECI*.
 * Uses version *PDF/X-4*.

To print them at Mein Spiel, use [this link][5] and select the 59*91mm and 55 cards option.

If you want to print them somewhere else and have different format requirements, you can contact me.
A possible modification would for example be a different cutout border (which will not affect the design).
However, I obviously cannot easily re-layout these cards with different content dimensions.

## Contact

If you have questions or feedback, you can contact me via mail at `contact@flyx.org`, or via [Matrix][6] at `@flyx:klacker.eu`.

 [1]: https://www.reddit.com/r/genesysrpg/comments/1or4znp/mass_effect_setting_version_20/
 [2]: https://www.fantasyflightgames.com/en/products/genesys/
 [3]: https://flyx.org/
 [4]: https://www.meinspiel.de/gestaltungsleitfaden-spielkarten-format-59x91-mm/
 [5]: https://www.meinspiel.de/selbstgestaltete-spielkarten-mit-fotos-gestalten-drucken/
 [6]: https://matrix.org/
